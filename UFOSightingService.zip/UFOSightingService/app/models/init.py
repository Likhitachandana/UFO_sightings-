from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

from app.models import sighting